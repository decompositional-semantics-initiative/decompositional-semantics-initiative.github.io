# Event Structure (v1.0)

This archive contains the instructions for, and data collected from, the protocols described in the following paper.

Gantt, W., L. Glass, & A. S. White 2021. Decomposing and Recomposing Event Structure.

The code for the sentence- and document-level models described therein is available [here](https://github.com/wgantt/event_type_induction). If you make use of the data, protocols, or code in a presentation or publication, we ask that you please cite the above paper.

The archive contains ten files apart from this one:
1. `event_structure_pred_udewt_v1.tsv`
2. `event_structure_pred_arg_udewt_v1.tsv`
3. `event_structure_pred_pred_udewt_v1.tsv`
4. `event_4_posteriors.tsv`
5. `entity_8_posteriors.tsv`
6. `role_2_posteriors.tsv`
7. `relation_5_posteriors.tsv`
8. `event_event_protocol.html`
9. `event_entity_protocol.html`
10. `event_subevent_protocol.html`

The first three files contain raw annotations from the three subprotocols described in the paper. The next four files contain the (unnormalized) log posterior distributions over types that were learned for each of the four ontologies using the generative model described in section 6 of the paper. The final three files contain the exact HTML of the instructions for each protocol on Amazon Mechanical Turk. The data and posterior files (1-7 above) are described in greater detail below.

## Annotations

Dataset splits, (anonymized) annotator IDs, and corpus sentence IDs are provided for all annotations. Additionally, for all properties in all three subprotocols, annotators were asked to provide a Likert-scale confidence rating, with 0 corresponding to "not at all confident" and 4 corresponding to "totally confident." 

### Event-Subevent Subprotocol

Annotations for the event-subevent subprotocol are provided in `event_structure_pred_udewt_v1.tsv`. These annotations were collected for Universal Decompositional Semantics (UDS) predicate nodes. Full column information is provided below. For properties relating to duration, the possible responses were presented as nominal categories. The names of these categories and their associated numeric value is as follows:

0. Effectively no time at all
1. Fractions of a second
2. Seconds
3. Minutes
4. Hours
5. Days
6. Weeks
7. Months
8. Years
9. Decades
10. Centuries
11. Effectively forever

| Column            | Description       | Values            |
|-------------------|-------------------|-------------------|
| Split | The dataset split to which annotation belongs | `train`, `dev`, `test` |
| Annotator.ID | The annotator that provided the response | `1, ..., 60` |
| Sentence.ID | The file and sentence number of the sentence in the English Universal Dependencies v1.2 treebank with the format `LANGUAGE-CORPUS-SPLIT.ANNOTATION SENTNUM` | string-valued, see data |
| Pred.ID | A corpus-unique identifier for the predicate comprising the (underscore-separated) `Sentence.ID` and the index of the predicate root within the sentence | string-valued, see data |
| Pred.Span | The indices within the sentence of all tokens in the predicate span (underscore-separated) | string-valued, see data |
| Pred.Text | The text of the predicate span | string-valued, see data |
| Has.Natural.Parts | Whether the predicate has natural parts | `0 (False), 1 (True)` |
| Has.Natural.Parts.Confidence | Annotator confidence for the `Has.Natural.Parts` property | `0, ..., 4` |
| Is.Telic | Whether the predicate has a natural endpoint (i.e. is telic) | `0 (False), 1 (True)` |
| Is.Telic.Confidence | Annotator confidence for the `Is.Telic` property | `0, ..., 4` |
| Situation.Duration.Lower.Bound | The lower bound on long the entire situation described by the predicate lasted | `0, ..., 11` |
| Situation.Duration.Lower.Bound.Confidence | Annotator confidence for the `Situation.Duration.Lower.Bound` property | `0, ..., 4` |
| Situation.Duration.Upper.Bound | The upper bound on long the entire situation described by the predicate lasted | `0, ..., 11` |
| Situation.Duration.Upper.Bound.Confidence | Annotator confidence for the `Situation.Duration.Upper.Bound` property | `0, ..., 4` |
| Has.Similar.Parts | If the predicate has natural parts, whether those parts are similar to one another | `0 (False), 1 (True)` |
| Has.Similar.Parts.Confidence | Annotator confidence for the `Has.Similar.Parts` property | `0, ..., 4` |
| Average.Subpart.Duration.Lower.Bound | If the predicate has natural parts, the lower bound on how long each subpart lasted | `0, ..., 11` |
| Average.Subpart.Duration.Lower.Bound.Confidence | Annotator confidence for the `Average.Subpart.Duration.Lower.Bound` property | `0, ..., 4` |
| Average.Subpart.Duration.Upper.Bound | If the predicate has natural parts, the upper bound on how long each subpart lasted | `0, ..., 11` |
| Average.Subpart.Duration.Upper.Bound.Confidence | Annotator confidence for the `Average.Subpart.Duration.Upper.Bound` property | `0, ..., 4` |

### Event-Entity Subprotocol

Annotations for the event-subevent subprotocol are provided in `event_structure_pred_arg_udewt_v1.tsv`. These annotations were collected for UDS predicate-argument (semantics) edges.

| Column            | Description       | Values            |
|-------------------|-------------------|-------------------|
| Split | The dataset split to which annotation belongs | `train`, `dev`, `test` |
| Annotator.ID | The annotator that provided the response | `1, ..., 38` |
| Sentence.ID | The file and sentence number of the sentence in the English Universal Dependencies v1.2 treebank with the format `LANGUAGE-CORPUS-SPLIT.ANNOTATION SENTNUM` | string-valued, see data |
| Pred.ID | A corpus-unique identifier for the predicate comprising the (underscore-separated) `Sentence.ID` and the index of the predicate root within the sentence | string-valued, see data |
| Pred.Span | The indices within the sentence of all tokens in the predicate span (underscore-separated) | string-valued, see data |
| Pred.Text | The text of the predicate span | string-valued, see data |
| Arg.ID | A corpus-unique identifier for the argument comprising the (underscore-separated) `Sentence.ID` and the index of the argument root within the sentence | string-valued, see data |
| Arg.Span | The indices within the sentence of all tokens in the argument span (underscore-separated) | string-valued, see data |
| Arg.Text | The text of the argument span | string-valued, see data |
| Distributive | Whether the argument is distributive with respect to the predicate | `0 (False), 1 (True)` |
| Confidence | Annotator confidence for the `Distributive` property | `0, ..., 4` |

### Event-Event Subprotocol

Finally, annotations for the event-subevent subprotocol are provided in `event_structure_pred_arg_udewt_v1.tsv`. These annotations were collected for UDS document edges, which may connect predicates or arguments within the same sentence or between different sentences. Thus, the "predicates" associated with each annotation (`Pred1` and `Pred2`) may in fact refer to argument nodes in UDS graphs.


| Column            | Description       | Values            |
|-------------------|-------------------|-------------------|
| Split | The dataset split to which annotation belongs | `train`, `dev`, `test` |
| Annotator.ID | The annotator that provided the response | `0, ..., 35` |
| Sentence1.ID | The file and sentence number of the sentence containing the first predicate (`Pred1`) in the English Universal Dependencies v1.2 treebank with the format `LANGUAGE-CORPUS-SPLIT.ANNOTATION SENTNUM` | string-valued, see data |
| Pred1.ID | A corpus-unique identifier for `Pred1` comprising the (underscore-separated) `Sentence.ID` and the index of the predicate root within the sentence | string-valued, see data |
| Pred1.Span | The indices within the sentence of all tokens in the predicate span for `Pred1` (underscore-separated) | string-valued, see data |
| Pred1.Text | The text of the predicate span for `Pred1` | string-valued, see data |
| Sentence1.ID | The file and sentence number of the sentence containing the first predicate (`Pred2`) in the English Universal Dependencies v1.2 treebank with the format `LANGUAGE-CORPUS-SPLIT.ANNOTATION SENTNUM` | string-valued, see data |
| Pred1.ID | A corpus-unique identifier for `Pred2` comprising the (underscore-separated) `Sentence.ID` and the index of the predicate root within the sentence | string-valued, see data |
| Pred1.Span | The indices within the sentence of all tokens in the predicate span for `Pred2` (underscore-separated) | string-valued, see data |
| Pred1.Text | The text of the predicate span for `Pred2` | string-valued, see data |
| Pred1.Contains.Pred2 | Whether the event denoted by `Pred2` is a mereological part of the one denoted by `Pred1` | `0 (False), 1 (True)` |
| Pred1.Contains.Pred2.Confidence | Annotator confidence for the `Pred1.Contains.Pred2` property | `0, ..., 4` |
| Pred2.Contains.Pred1 | Whether the event denoted by `Pred1` is a mereological part of the one denoted by `Pred2` | `0 (False), 1 (True)` |
| Pred2.Contains.Pred1.Confidence | Annotator confidence for the `Pred2.Contains.Pred1` property | `0, ..., 4` |

**Note**: Owing to an experimental error, certain items in the dev split have more than three annotations. There is nothing inferior about the quality of annotations on these items; they are simply additional data that we include for completeness, as they were used in evaluating our protocol and models.

Due to a separate issue in the data collection, there are 48 predicate-argument pairs that cross document boundaries, though they should not. These are automatically filtered out when the annotations are loaded into the document-level graphs when using the Decomp Toolkit and should similarly be disregarded for any intra-document tasks that use these annotations. The document edge IDs for these annotations are provided below (given in the form NODE1%%NODE2):

```
['ewt-dev-793-document-pred-1%%ewt-dev-794-document-arg-43',
 'ewt-dev-1777-document-pred-6%%ewt-dev-1778-document-arg-4',
 'ewt-dev-1520-document-pred-2%%ewt-dev-1521-document-arg-10',
 'ewt-dev-1827-document-arg-6%%ewt-dev-1828-document-pred-7',
 'ewt-dev-1530-document-arg-9%%ewt-dev-1531-document-pred-4',
 'ewt-dev-1746-document-arg-14%%ewt-dev-1747-document-pred-4',
 'ewt-dev-1521-document-arg-10%%ewt-dev-1522-document-pred-13',
 'ewt-test-69-document-arg-25%%ewt-test-70-document-pred-4',
 'ewt-test-19-document-arg-20%%ewt-test-20-document-pred-23',
 'ewt-test-19-document-pred-12%%ewt-test-20-document-arg-5',
 'ewt-test-19-document-arg-20%%ewt-test-20-document-pred-35',
 'ewt-test-19-document-arg-20%%ewt-test-20-document-pred-17',
 'ewt-test-19-document-arg-20%%ewt-test-20-document-arg-5',
 'ewt-test-19-document-pred-5%%ewt-test-20-document-arg-5',
 'ewt-test-19-document-arg-20%%ewt-test-20-document-pred-3',
 'ewt-test-19-document-pred-13%%ewt-test-20-document-arg-5',
 'ewt-test-19-document-arg-20%%ewt-test-20-document-pred-1',
 'ewt-test-19-document-arg-20%%ewt-test-20-document-pred-32',
 'ewt-test-1995-document-pred-6%%ewt-test-1996-document-arg-4',
 'ewt-test-838-document-pred-11%%ewt-test-839-document-arg-5',
 'ewt-train-8572-document-arg-7%%ewt-train-8573-document-pred-5',
 'ewt-train-8572-document-arg-7%%ewt-train-8573-document-pred-1',
 'ewt-train-10119-document-pred-13%%ewt-train-10120-document-arg-12',
 'ewt-train-7479-document-pred-19%%ewt-train-7480-document-arg-6',
 'ewt-train-10432-document-pred-5%%ewt-train-10433-document-arg-27',
 'ewt-train-10391-document-arg-9%%ewt-train-10392-document-pred-42',
 'ewt-train-10391-document-arg-9%%ewt-train-10392-document-pred-44',
 'ewt-train-10391-document-arg-9%%ewt-train-10392-document-pred-24',
 'ewt-train-10391-document-arg-9%%ewt-train-10392-document-pred-26',
 'ewt-train-10391-document-arg-9%%ewt-train-10392-document-pred-11',
 'ewt-train-10391-document-arg-9%%ewt-train-10392-document-pred-16',
 'ewt-train-10391-document-arg-9%%ewt-train-10392-document-pred-1',
 'ewt-train-11866-document-pred-5%%ewt-train-11867-document-arg-4',
 'ewt-train-10354-document-arg-8%%ewt-train-10355-document-pred-2',
 'ewt-train-10354-document-arg-8%%ewt-train-10355-document-pred-27',
 'ewt-train-10354-document-arg-8%%ewt-train-10355-document-pred-28',
 'ewt-train-10354-document-arg-8%%ewt-train-10355-document-pred-8',
 'ewt-train-10354-document-arg-8%%ewt-train-10355-document-pred-32',
 'ewt-train-10354-document-arg-8%%ewt-train-10355-document-pred-14',
 'ewt-train-10354-document-arg-8%%ewt-train-10355-document-pred-12',
 'ewt-train-12416-document-pred-9%%ewt-train-12417-document-arg-11',
 'ewt-train-8615-document-arg-8%%ewt-train-8616-document-pred-9',
 'ewt-train-8615-document-arg-8%%ewt-train-8616-document-pred-3',
 'ewt-train-8615-document-arg-8%%ewt-train-8616-document-pred-7',
 'ewt-train-8054-document-pred-4%%ewt-train-8055-document-arg-4',
 'ewt-train-10922-document-pred-2%%ewt-train-10923-document-arg-7',
 'ewt-train-9075-document-pred-5%%ewt-train-9076-document-arg-7',
 'ewt-train-7970-document-pred-6%%ewt-train-7971-document-arg-7']
```

## Per-Ontology Posteriors

The paper presents four interdependent, empirically derived ontologies for events, entities, (semantic) roles, and event-event relations. While the generative model described in the paper _jointly_ induces these ontologies, the appropriate number of types for each was determined via clustering _independently_ on each using a multi-view mixture model. This number is reflected in the name of the corresponding posteriors file (e.g. the "4" in `event_4_posteriors.tsv`). All columns are indexed by a UDS-based identifier appropriate to the ontology: a predicate node for event types; an argument node for entity types; a predicate-argument pair for role types; and a predicate/argument-predicate/argument pair for event-event relations. Each additional column in these files corresponds to a particular type for that ontology (`type0, type1, ...`). In the paper, we provide interpretive names for the types in each ontology, and the mapping from type numbers to interpretive names is given below. Please note that these reflect the authors' judgments of what are reasonable characterizations of each type based on the data.

### Event Types

Our event types align fairly well with the classical taxonomy of (Vendler 1957):

`type0`: Achievement
`type1`: Activity
`type2`: Accomplishment
`type3`: Stative

### Entity Types

Our entity types are as follows:

`type0`: Concrete artifact
`type1`: Contentful artifact
`type2`: Particular state or event
`type3`: Particular concrete object
`type4`: Generic concrete object
`type5`: Time
`type6`: Person or organization
`type7`: Generic state or event

### Role Types

Our role types correspond closely to the proto-patient and proto-agent of (Dowty 1991):

`type0`: Proto-patient
`type1`: Proto-agent

### Event-Event Relation Types

Let `e1` and `e2` denote two events. Our relation types are as follows:

`type0`: `e1` contains `e2`
`type1`: `e1` and `e2` are the same event
`type2`: `e2` ends after `e1`
`type3`: `e2` starts before `e1`
`type4`: `e1` starts before `e2`
